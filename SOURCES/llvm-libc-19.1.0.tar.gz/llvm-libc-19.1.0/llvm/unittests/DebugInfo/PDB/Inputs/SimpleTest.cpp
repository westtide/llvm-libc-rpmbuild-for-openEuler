// Compile with "cl /c /Zi SimpleTest.cpp"
// Link with "link SimpleTest.obj /debug /nodefaultlib /entry:main"

int main() { return 0; }
